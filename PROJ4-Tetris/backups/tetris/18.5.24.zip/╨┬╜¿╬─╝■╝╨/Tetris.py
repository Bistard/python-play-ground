import pygame
import math
import random

pygame.init()

BLACK = [0, 0, 0]
WHITE = [255, 255, 255]
GREY = [100,100,100]

LIGHTPURPLE = [200,191,231]
ORANGE = [255,173,91]
BLUE = [4,180,255]

window_width, window_height = 750, 950
clock = pygame.time.Clock()
background = pygame.image.load('background.png')


def text_objects(text,font,color):
    textsurface = font.render(text,True,color)
    return textsurface, textsurface.get_rect()
def text_display(window,text,size,coor_x,coor_y,color):
    largetext = pygame.font.Font('freesansbold.ttf',size)
    textsurf,textrect = text_objects(text,largetext,color)
    textrect.center = ((coor_x,coor_y))
    window.blit(textsurf,textrect)





def mainloop():
    mainwindow = pygame.display.set_mode((window_width, window_height))


    def I(x,y,state,color):
        if state == 0:
            for i in range(0,4):
                pygame.draw.rect(mainwindow,color, (x, y-80, 41, 40))
                y += 40
        elif state == 1:
            for i in range(0,4):
                pygame.draw.rect(mainwindow,color, (x - 40, y, 41, 40))
                x += 40
        elif state == 2:
            for i in range(0, 4):
                pygame.draw.rect(mainwindow,color, (x, y - 40, 41, 40))
                y += 40
        elif state == 3:
            for i in range(0,4):
                pygame.draw.rect(mainwindow,color, (x - 80, y, 41, 40))
                x += 40
    def L(x,y,state,color):
        if state == 0:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x, y - 40, 41, 40))
                y += 40
            pygame.draw.rect(mainwindow, color, (x+40, y-80, 41, 40))
        elif state == 1:
            for i in range(0, 3):
                pygame.draw.rect(mainwindow, color, (x-40, y, 41, 40))
                x += 40
            pygame.draw.rect(mainwindow,color, (x-160, y+40, 41, 40))
        elif state == 2:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x, y-40, 41, 40))
                y += 40
            pygame.draw.rect(mainwindow, color, (x - 40, y-160, 41, 40))
        elif state == 3:
            for i in range(0,3):
                pygame.draw.rect(mainwindow,color, (x-40, y, 41, 40))
                x += 40
            pygame.draw.rect(mainwindow,color, (x-80, y-40, 41, 40))
    def J(x,y,state,color):
        if state == 0:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x, y - 40, 41, 40))
                y += 40
            pygame.draw.rect(mainwindow, color, (x - 40, y - 80, 41, 40))
        elif state == 1:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x - 40, y, 41, 40))
                x += 40
            pygame.draw.rect(mainwindow, color, (x - 160, y - 40, 41, 40))
        elif state == 2:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x, y-40, 41, 40))
                y += 40
            pygame.draw.rect(mainwindow, color, (x + 40, y - 160, 41, 40))
        elif state == 3:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x - 40, y, 41, 40))
                x += 40
            pygame.draw.rect(mainwindow, color, (x - 80, y+40, 41, 40))
    def O(x,y,state):
            pass

    def Z(x,y,state):
            pass

    def S(x,y,state):
            pass

    def T(x,y,state):
            pass

    QUIT = False
    count = 0
    count2 = -1
    shapes_xy = []
    shapes = []
    I_states = []
    L_states = []
    J_states = []
    O_states = []
    Z_states = []
    S_states = []
    T_states = []
    TOUCH = True


    def gamewindow(window_x,window_y,color,width):
        gw_width = 400
        gw_height = 800
        side = 40
        yy = window_y
        for i in range(0,math.floor(gw_height/side)):
            xx = window_x
            for ii in range(0,math.floor(gw_width/side)):
                pygame.draw.rect(mainwindow,color,(xx,yy,41,41),width)
                xx += 40
            yy += 40
    def collision():
        pass

    def moveAD(shape):
        pass

    def rotation(shape,count):
        if states[shape][count] < 3:
            states[shape][count] += 1
        else :
            states[shape][count] = 0

    def gravity():
        pass

    def g_shapes(shapes,shapes_x,shapes_y,states):
        if shapes == 0:
            I(shapes_x,shapes_y,states,LIGHTPURPLE)
            if count%60 == 0:
                pass
        elif shapes == 1:
            L(shapes_x, shapes_y, states,ORANGE)
            if count%60 == 0:
                pass
        elif shapes == 2:
            J(shapes_x, shapes_y, states, BLUE)
            if count%60 == 0:
                pass
        elif shapes == 3:
            pass

    while not QUIT:
        mainwindow.blit(background,(0,0))
        gamewindow(160,100,WHITE,0)
        count += 1
        
        if TOUCH == True:
            shape = random.randint(0,2)
            shapes.append(shape)
            if shape == 0:
                I_states.append(0)
            elif shape == 1:
                L_states.append(0)
            elif shape == 2:
                J_states.append(0)
            elif shape == 3:
                O_states.append(0)
            elif shape == 4:
                Z_states.append(0)
            elif shape == 5:
                S_states.append(0)
            elif shape == 6:
                T_states.append(0)
            shapes_xy.append([320,100])
            count2 += 1
            #shape = 3
            states = [I_states,L_states,J_states,O_states,Z_states,S_states,T_states]
            print(states)
            TOUCH = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w:
                    rotation(shape,count2)
                if event.key == pygame.K_a:
                    pass
                if event.key == pygame.K_d:
                    pass
        for i in range(0,len(shapes)):
            g_shapes(shapes[i],shapes_xy[i][0],shapes_xy[i][1],states[shapes[i]][i]) 
        if count % 60 == 0 and shapes_xy[i][1] < 820:
            shapes_xy[i][1] += 40
        if shapes_xy[i][1] >= 820:
            TOUCH = True
        


        gamewindow(160,100,BLACK,2)
        pygame.display.update()
        clock.tick(60)
mainloop()

