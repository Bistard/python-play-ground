import pygame
import math
import random

pygame.init()

BLACK = [0, 0, 0]
WHITE = [255, 255, 255]
GREY = [50,50,50]
LIGHTGREY = [100,100,100]

LIGHTBLUE = [108,255,255]
ORANGE = [255,173,91]
BLUE = [4,180,255]
YELLOW = [255,242,9]
RED = [241,78,86]
GREEN = [181,230,29]
PURPLE = [179,83,179]

window_width, window_height = 750, 950
clock = pygame.time.Clock()
background = pygame.image.load('background.png')
menu = pygame.image.load('menu.png')
STATS = pygame.image.load('STATS.png')

Ii = pygame.image.load('tetrises/Ii.jpg')
Ii = pygame.transform.scale(Ii,(20,80))
Jj = pygame.image.load('tetrises/Jj.png')
Jj = pygame.transform.scale(Jj,(40,60))
Ll = pygame.image.load('tetrises/Ll.png')
Ll = pygame.transform.scale(Ll,(40,60))
Oo = pygame.image.load('tetrises/Oo.jpg')
Oo = pygame.transform.scale(Oo,(40,40))
Ss = pygame.image.load('tetrises/Ss.png')
Ss = pygame.transform.scale(Ss,(40,60))
Tt = pygame.image.load('tetrises/Tt.png')
Tt = pygame.transform.scale(Tt,(60,40))
Zz = pygame.image.load('tetrises/Zz.png')
Zz = pygame.transform.scale(Zz,(40,60))
SPACE = pygame.image.load('samples/SPACE.jpg')
SPACE = pygame.transform.scale(SPACE,(80,30))
W = pygame.image.load('samples/W.jpg')
W = pygame.transform.scale(W,(30,30))
A = pygame.image.load('samples/A.jpg')
A = pygame.transform.scale(A,(30,30))
S = pygame.image.load('samples/S.jpg')
S = pygame.transform.scale(S,(30,30))
D = pygame.image.load('samples/D.jpg')
D = pygame.transform.scale(D,(30,30))

def text_objects(text,font,color):
    textsurface = font.render(text,True,color)
    return textsurface, textsurface.get_rect()

def text_display(window,text,size,coors,color):
    largetext = pygame.font.Font('freesansbold.ttf',size)
    textsurf,textrect = text_objects(text,largetext,color)
    textrect.center = (coors)
    window.blit(textsurf,textrect)

def buttom(window,color,coors,size,text,textsize,textcolor):
    pygame.draw.rect(window,color,(coors,size))
    pygame.draw.rect(window,WHITE,(coors,size),3)
    text_display(window,text,textsize,(coors[0]+math.floor(size[0]/2),coors[1]+math.floor(size[1]/2)),textcolor)

def startmenu():

    mainwindow = pygame.display.set_mode((window_width, window_height))
    textsize = 30
    while True:
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        mainwindow.blit(menu,(0,0))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()

        if 235 < mouse[0] < 415 and 500 < mouse[1] < 550:
            GO = buttom(mainwindow,LIGHTGREY,(235,500),(180,50),'GO',textsize,WHITE)
            if click[0] == 1:
                return 'Go'
        else:
            GO = buttom(mainwindow,GREY,(235,500),(180,50),'GO',30,WHITE)

        if 335 < mouse[0] < 515 and 580 < mouse[1] < 660:
            STATS = buttom(mainwindow,LIGHTGREY,(335,580),(180,50),'STATS',textsize,WHITE)
            if click[0] == 1:
                return 'Stats'
        else:
            STATS = buttom(mainwindow,GREY,(335,580),(180,50),'STATS',textsize,WHITE)
        
        if 235 < mouse[0] < 415 and 660 < mouse[1] < 740:
            TUTORIAL = buttom(mainwindow,LIGHTGREY,(235,660),(180,50),'TUTORIAL',textsize,WHITE)
            if click[0] == 1:
                mainwindow.blit(SPACE,(135,680))
                mainwindow.blit(W,(60,645))
                mainwindow.blit(A,(25,680))
                mainwindow.blit(S,(60,680))
                mainwindow.blit(D,(95,680))
        else:
            TUTORIAL = buttom(mainwindow,GREY,(235,660),(180,50),'TUTORIAL',textsize,WHITE)
        
        if 335 < mouse[0] < 515 and 740 < mouse[1] < 820:
            EXIT = buttom(mainwindow,LIGHTGREY,(335,740),(180,50),'EXIT',textsize,WHITE)
            if click[0] == 1:
                return 'Exit'
        else:
            EXIT = buttom(mainwindow,GREY,(335,740),(180,50),'EXIT',textsize,WHITE)

        pygame.display.update()
        clock.tick(60)

def stats():
    mainwindow = pygame.display.set_mode((window_width, window_height))
    while True:
        textsize = 20
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        mainwindow.blit(STATS,(0,0))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()

        with open('RecentStats.txt', 'r') as recent:
            coors = [200,400]
            for line in recent.readlines(): 
                line = line.strip('\n')
                text_display(mainwindow,line,textsize,coors,WHITE)
                coors[1] += 50
        with open('TotalStats.txt','r') as total:
            coors = [560,400]
            for line in total.readlines():
                line = line.strip('\n')
                text_display(mainwindow,line,textsize,(coors[0],coors[1]),WHITE)
                coors[1] += 50

        text_display(mainwindow,'Recent',60,(200,350),WHITE)
        text_display(mainwindow,'Total',60,(560,350),WHITE)
        if 20 < mouse[0] < 100 and 880 < mouse[1] < 920:
            buttom(mainwindow,LIGHTGREY,(20,880),(80,40),'BACK',20,WHITE)
            if click[0] == 1:
                return
        else:
            buttom(mainwindow,GREY,(20,880),(80,40),'BACK',20,WHITE)
        pygame.display.update()
        clock.tick(60)

def mainloop():
    mainwindow = pygame.display.set_mode((window_width, window_height))

    def I(state):
        if state == 0:
            for i in range(0,4):
                updatecoors(i,[i+LRD[2][0],LRD[0][0]])
                updatec_zone()
        if state == 1:
            for i in range(0,4):
                updatecoors(i,[LRD[2][0]+2,i+LRD[0][0]-1])
                updatec_zone()
        if state == 2:
            for i in range(0,4):
                updatecoors(i,[i+LRD[2][0]+1,LRD[0][0]])
                updatec_zone()
        if state == 3:
            for i in range(0,4):
                updatecoors(i,[LRD[2][0]+2,i+LRD[0][0]-2])
                updatec_zone()
    def L(state):
        if state == 0:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[i+LRD[2][0],LRD[0][0]])
                if i == 3:
                    updatecoors(i,[LRD[2][0]+2,LRD[0][0]+1])
                updatec_zone()
        if state == 1:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]+1-i])
                if i == 3:
                    updatecoors(i,[LRD[2][0]+2,LRD[0][0]-1])
                updatec_zone()
        if state == 2:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[i+LRD[2][0],LRD[0][0]])
                if i == 3:
                    updatecoors(i,[LRD[2][0],LRD[0][0]-1])
                updatec_zone()
        if state == 3:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]-1+i])
                if i == 3:
                    updatecoors(i,[LRD[2][0],LRD[0][0]+1])
                updatec_zone()
    def J(state):
        if state == 0:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[i+LRD[2][0],LRD[0][0]])
                if i == 3:
                    updatecoors(i,[LRD[2][0]+2,LRD[0][0]-1])
                updatec_zone()
        if state == 1:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]+1-i])
                if i == 3:
                    updatecoors(i,[LRD[2][0],LRD[0][0]-1])
                updatec_zone()
        if state == 2:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[i+LRD[2][0],LRD[0][0]])
                if i == 3:
                    updatecoors(i,[LRD[2][0],LRD[0][0]+1])
                updatec_zone()
        if state == 3:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]-1+i])
                if i == 3:
                    updatecoors(i,[LRD[2][0]+2,LRD[0][0]+1])
                updatec_zone()
    def O(state):
        for i in range(0,4):
            if i < 2:
                updatecoors(i,[LRD[2][0],LRD[0][0]+i])
            elif i >= 2:
                updatecoors(i,[LRD[2][0]+1,LRD[0][0]-2+i])
            updatec_zone()
    def Z(state):
        if state == 0:
            for i in range(0,4):
                if i < 2:
                    updatecoors(i,[i+LRD[2][0],LRD[0][0]])
                elif i >= 2:
                    updatecoors(i,[i+LRD[2][0]-1,LRD[0][0]-1])
                updatec_zone()
        if state == 1:
            for i in range(0,4):
                if i < 2:
                    updatecoors(i,[LRD[2][0],LRD[0][0]-1+i])
                elif i >= 2:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]-2+i])
                updatec_zone()
        if state == 2:
            for i in range(0,4):
                if i < 2:
                    updatecoors(i,[i+LRD[2][0],LRD[0][0]+1])
                elif i >= 2:
                    updatecoors(i,[i+LRD[2][0]-1,LRD[0][0]])
                updatec_zone()
        if state == 3:
            for i in range(0,4):
                if i < 2:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]-1+i])
                elif i >= 2:
                    updatecoors(i,[LRD[2][0]+2,LRD[0][0]-2+i])
                updatec_zone()
    def S(state):
        if state == 0:
            for i in range(0,4):
                if i < 2:
                    updatecoors(i,[i+LRD[2][0],LRD[0][0]])
                elif i >= 2:
                    updatecoors(i,[i+LRD[2][0]-1,LRD[0][0]+1])
                updatec_zone()
        if state == 1:
            for i in range(0,4):
                if i < 2:
                    updatecoors(i,[LRD[2][0],LRD[0][0]+2-i])
                elif i >= 2:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]+3-i])
                updatec_zone()
        if state == 2:
            for i in range(0,4):
                if i < 2:
                    updatecoors(i,[i+LRD[2][0],LRD[0][0]+1])
                elif i >= 2:
                    updatecoors(i,[i+LRD[2][0]-1,LRD[0][0]+2])
                updatec_zone()
        if state == 3:
            for i in range(0,4):
                if i < 2:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]+2-i])
                elif i >= 2:
                    updatecoors(i,[LRD[2][0]+2,LRD[0][0]+3-i])
                updatec_zone()
    def T(state):
        if state == 0:
            for i in range(0,4):
                if i < 1:
                    updatecoors(i,[LRD[2][0],LRD[0][0]])
                elif i >= 1:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]-2+i])
                updatec_zone()
        if state == 1:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[i+LRD[2][0],LRD[0][0]])
                elif i == 3:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]+1])
                updatec_zone()
        if state == 2:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]-1+i])
                elif i == 3:
                    updatecoors(i,[LRD[2][0]+2,LRD[0][0]])
                updatec_zone()
        if state == 3:
            for i in range(0,4):
                if i < 3:
                    updatecoors(i,[i+LRD[2][0],LRD[0][0]])
                if i == 3:
                    updatecoors(i,[LRD[2][0]+1,LRD[0][0]-1])
                updatec_zone()
    QUIT = False
    count = 0
    count2 = 0
    plus = 0
    coors_tetris = []
    states = []
    shapes = []
    shapes_pics = [Ii,Ll,Jj,Oo,Zz,Ss,Tt]

    zone = [[0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],     #  window: 750 x 950
            [0,0,0,0,0,0,0,0,0,0],      #  tetris zone: 400 x 800 
            [0,0,0,0,0,0,0,0,0,0],      #  start_coors: (160,100)
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [8,8,8,8,8,8,8,8,8,8]]

    c_zone = [[0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],    
              [0,0,0,0,0,0,0,0,0,0],    
              [0,0,0,0,0,0,0,0,0,0],     
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [0,0,0,0,0,0,0,0,0,0],
              [8,8,8,8,8,8,8,8,8,8]]

    TOUCH = [True]

    def updatezone():
        zone.clear()
        for i in range(0,22):
            zone.append(c_zone[i].copy())

    def updatec_zone():
        c_zone.clear()
        for i in range(0,22):
            c_zone.append(zone[i].copy())

    def printzone(): #for the testing
        for i in range(0,22):
            print(zone[i])
        print('------------------------------')

    def printc_zone(): #for the testing
        for i in range(0,22):
            print(c_zone[i])
        print('------------------------------')

    def updategrid(window_x,window_y,color,width):
        gw_width = 400
        gw_height = 800
        side = 40
        yy = window_y
        for i in range(0,math.floor(gw_height/side)):
            xx = window_x
            for ii in range(0,math.floor(gw_width/side)):
                pygame.draw.rect(mainwindow,color,(xx,yy,41,41),width)
                xx += 40
            yy += 40

    def updatetetris():
        y = 60
        for i in range(0,21):
            x = 160
            for ii in range(0,10):
                if i == 0:
                    break
                if c_zone[i][ii] == 0:
                    pygame.draw.rect(mainwindow,GREY,(x,y,41,41))
                if c_zone[i][ii] == 1:
                    pygame.draw.rect(mainwindow,LIGHTBLUE,(x,y,41,41))
                if c_zone[i][ii] == 2:
                    pygame.draw.rect(mainwindow,ORANGE,(x,y,41,41))
                if c_zone[i][ii] == 3:
                    pygame.draw.rect(mainwindow,BLUE,(x,y,41,41))
                if c_zone[i][ii] == 4:
                    pygame.draw.rect(mainwindow,YELLOW,(x,y,41,41))
                if c_zone[i][ii] == 5:
                    pygame.draw.rect(mainwindow,RED,(x,y,41,41))
                if c_zone[i][ii] == 6:
                    pygame.draw.rect(mainwindow,GREEN,(x,y,41,41))
                if c_zone[i][ii] == 7:
                    pygame.draw.rect(mainwindow,PURPLE,(x,y,41,41))
                x += 40
            y += 40

    def moveASD(ASD):
        if ASD == 'A' and LRD[0][0] > 0:
            LRD[0][0] -= 1
        elif ASD == 'D' and LRD[0][0] < 9: 
            LRD[0][0] += 1
        if ASD == 'S':
            LRD[2][0] += 1

    def rotation():
        if states[-1] < 3:
            states[-1] += 1
        else :
            states[-1] = 0
    
    def falling(i):
        if c_zone[i+LRD[2][0]][LRD[0][0]] != 0 and count % 60 == 0:
            TOUCH.append(True)
            return True

    def gravity():
        for i in range(0,4):
            #print(coors_tetris)
            if c_zone[coors_tetris[i][0]][coors_tetris[i][1]] != 0:
                return True
        return False

    def updatecoors(i,coors):
        coors_tetris.append(coors)

    def moverow():
        pass
    
    def g_tetrises(shape,states):
        if shape == 0:
            I(states)
        elif shape == 1:
            L(states)
        elif shape == 2:
            J(states)
        elif shape == 3:
            O(states)
        elif shape == 4:
            Z(states)
        elif shape == 5:
            S(states)
        elif shape == 6:
            T(states)

    def g_numbers(zone,i,shape):
        if shape == 0:
            zone[coors_tetris[i][0]-1][coors_tetris[i][1]] = 1
        if shape == 1:
            zone[coors_tetris[i][0]-1][coors_tetris[i][1]] = 2
        if shape == 2:
            zone[coors_tetris[i][0]-1][coors_tetris[i][1]] = 3
        if shape == 3:
            zone[coors_tetris[i][0]-1][coors_tetris[i][1]] = 4
        if shape == 4:
            zone[coors_tetris[i][0]-1][coors_tetris[i][1]] = 5
        if shape == 5:
            zone[coors_tetris[i][0]-1][coors_tetris[i][1]] = 6
        if shape == 6:
            zone[coors_tetris[i][0]-1][coors_tetris[i][1]] = 7

    def gameover():
        pass

    for i in range(0,6):
        shapes.append(random.randint(0,6))
    while not QUIT:
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        mainwindow.blit(background,(0,0))
        count += 1
        count2 += plus
        if TOUCH[-1] == True:
            count = 0
            LRD = [[4],[0],[0]]
            del(shapes[-1])
            shapes.insert(0,random.randint(0,6))
            shape = shapes[-1]
            states.append(0)
            TOUCH.append(False)
        g_tetrises(shape,states[-1])
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    while True:
                        g_tetrises(shape,states[-1])
                        if gravity() == False:
                            LRD[2][0] += 1
                            coors_tetris.clear()
                        elif gravity() == True:
                            for i in range(0,4):
                                g_numbers(zone,i,shape)
                            break
                    TOUCH[-1] = True
                if event.key == pygame.K_w:
                    rotation()
                if event.key == pygame.K_a:
                    count2 = 0
                    plus = -1
                    moveASD('A')
                if event.key == pygame.K_d:
                    count2 = 0
                    plus = 1
                    moveASD('D')
                if event.key == pygame.K_s:
                    moveASD('S')
        
        if count2 % 8 == 0 and count2 < 0:
            moveASD(True)
        if count2 % 8 == 0 and count2 > 0:
            moveASD(False)

        

        if gravity() == True:
            TOUCH.append(True)
            for i in range(0,4):
                g_numbers(zone,i,shape)
        elif gravity() == False:
            for i in range(0,4):
                g_numbers(c_zone,i,shape)
        
        if count % 60 == 0:
            LRD[2][0] += 1
        #if count % 60 == 0:
            #printc_zone()
        

        updatetetris()
        coors_tetris.clear()
        
        if shape == 0:
            mainwindow.blit(Ii,(660,70))
        elif shape == 1:
            mainwindow.blit(Ll,(650,80))
        elif shape == 2:
            mainwindow.blit(Jj,(650,80))
        elif shape == 3:
            mainwindow.blit(Oo,(650,90))
        elif shape == 4:
            mainwindow.blit(Zz,(650,80))
        elif shape == 5:
            mainwindow.blit(Ss,(650,80))
        elif shape == 6:
            mainwindow.blit(Tt,(640,90))

        y = 680
        for i in shapes[0:5]:
            mainwindow.blit(shapes_pics[i],(650,y))
            y -= 100

        text_display(mainwindow,'SCORE',30,(70,40),WHITE)
        text_display(mainwindow,'LEVEL',30,(70,200),WHITE)
        text_display(mainwindow,'HOLD',30,(670,40),WHITE)
        text_display(mainwindow,'NEXT',30,(670,200),WHITE)
        if 20 < mouse[0] < 100 and 880 < mouse[1] < 920:
            buttom(mainwindow,LIGHTGREY,(20,880),(80,40),'BACK',20,WHITE)
            if click[0] == 1:
                return
        else:
            buttom(mainwindow,GREY,(20,880),(80,40),'BACK',20,WHITE)


        updategrid(160,100,WHITE,2)
        pygame.display.update()
        clock.tick(60)


while True:
    LEVEL = startmenu()
    if LEVEL == 'Go':
        mainloop()
    elif LEVEL == 'Stats':
        stats()
    elif LEVEL == 'Exit':
        pygame.quit()
        quit()