import pygame
import math
import random

pygame.init()

BLACK = [0, 0, 0]
WHITE = [255, 255, 255]
GREY = [50,50,50]
LIGHTGREY = [100,100,100]

LIGHTBLUE = [108,255,255]
ORANGE = [255,173,91]
BLUE = [4,180,255]
YELLOW = [255,242,9]
RED = [241,78,86]
GREEN = [181,230,29]
PURPLE = [179,83,179]

window_width, window_height = 750, 950
clock = pygame.time.Clock()
background = pygame.image.load('background.png')
menu = pygame.image.load('menu.png')
STATS = pygame.image.load('STATS.png')
SPACE = pygame.image.load('samples/SPACE.jpg')
W = pygame.image.load('samples/W.jpg')
A = pygame.image.load('samples/A.jpg')
S = pygame.image.load('samples/S.jpg')
D = pygame.image.load('samples/D.jpg')
SPACE = pygame.transform.scale(SPACE,(80,30))
W = pygame.transform.scale(W,(30,30))
A = pygame.transform.scale(A,(30,30))
S = pygame.transform.scale(S,(30,30))
D = pygame.transform.scale(D,(30,30))

def text_objects(text,font,color):
    textsurface = font.render(text,True,color)
    return textsurface, textsurface.get_rect()

def text_display(window,text,size,coors,color):
    largetext = pygame.font.Font('freesansbold.ttf',size)
    textsurf,textrect = text_objects(text,largetext,color)
    textrect.center = (coors)
    window.blit(textsurf,textrect)

def buttom(window,color,coors,size,text,textsize,textcolor):
    pygame.draw.rect(window,color,(coors,size))
    pygame.draw.rect(window,WHITE,(coors,size),3)
    text_display(window,text,textsize,(coors[0]+math.floor(size[0]/2),coors[1]+math.floor(size[1]/2)),textcolor)

def startmenu():

    mainwindow = pygame.display.set_mode((window_width, window_height))
    textsize = 30
    while True:
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        mainwindow.blit(menu,(0,0))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()

        if 235 < mouse[0] < 415 and 500 < mouse[1] < 550:
            GO = buttom(mainwindow,LIGHTGREY,(235,500),(180,50),'GO',textsize,WHITE)
            if click[0] == 1:
                return 'Go'
        else:
            GO = buttom(mainwindow,GREY,(235,500),(180,50),'GO',30,WHITE)

        if 335 < mouse[0] < 515 and 580 < mouse[1] < 660:
            STATS = buttom(mainwindow,LIGHTGREY,(335,580),(180,50),'STATS',textsize,WHITE)
            if click[0] == 1:
                return 'Stats'
        else:
            STATS = buttom(mainwindow,GREY,(335,580),(180,50),'STATS',textsize,WHITE)
        
        if 235 < mouse[0] < 415 and 660 < mouse[1] < 740:
            TUTORIAL = buttom(mainwindow,LIGHTGREY,(235,660),(180,50),'TUTORIAL',textsize,WHITE)
            if click[0] == 1:
                mainwindow.blit(SPACE,(135,680))
                mainwindow.blit(W,(60,645))
                mainwindow.blit(A,(25,680))
                mainwindow.blit(S,(60,680))
                mainwindow.blit(D,(95,680))
        else:
            TUTORIAL = buttom(mainwindow,GREY,(235,660),(180,50),'TUTORIAL',textsize,WHITE)
        
        if 335 < mouse[0] < 515 and 740 < mouse[1] < 820:
            EXIT = buttom(mainwindow,LIGHTGREY,(335,740),(180,50),'EXIT',textsize,WHITE)
            if click[0] == 1:
                return 'Exit'
        else:
            EXIT = buttom(mainwindow,GREY,(335,740),(180,50),'EXIT',textsize,WHITE)

        pygame.display.update()
        clock.tick(60)

def stats():
    mainwindow = pygame.display.set_mode((window_width, window_height))
    while True:
        textsize = 20
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        mainwindow.blit(STATS,(0,0))
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()

        with open('RecentStats.txt', 'r') as recent:
            coors = [200,400]
            for line in recent.readlines(): 
                line = line.strip('\n')
                text_display(mainwindow,line,textsize,coors,WHITE)
                coors[1] += 50
        with open('TotalStats.txt','r') as total:
            coors = [560,400]
            for line in total.readlines():
                line = line.strip('\n')
                text_display(mainwindow,line,textsize,(coors[0],coors[1]),WHITE)
                coors[1] += 50

        text_display(mainwindow,'Recent',60,(200,350),WHITE)
        text_display(mainwindow,'Total',60,(560,350),WHITE)
        if 20 < mouse[0] < 100 and 880 < mouse[1] < 920:
            buttom(mainwindow,LIGHTGREY,(20,880),(80,40),'BACK',20,WHITE)
            if click[0] == 1:
                return
        else:
            buttom(mainwindow,GREY,(20,880),(80,40),'BACK',20,WHITE)
        pygame.display.update()
        clock.tick(60)

def mainloop():
    mainwindow = pygame.display.set_mode((window_width, window_height))

    def I(x,y,state,color):
        updatec_zone()
        if state == 0:
            for i in range(0,4):
                if falling(i) == False:
                    c_zone[i+LRD[2][0]][LRD[0][0]] = 1
                    
    def L(x,y,state,color):
        if state == 0:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x, y - 40, 41, 40))
                y += 40
            pygame.draw.rect(mainwindow, color, (x+40, y-80, 41, 40))
        elif state == 1:
            for i in range(0, 3):
                pygame.draw.rect(mainwindow, color, (x-40, y, 41, 40))
                x += 40
            pygame.draw.rect(mainwindow,color, (x-160, y+40, 41, 40))
        elif state == 2:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x, y-40, 41, 40))
                y += 40
            pygame.draw.rect(mainwindow, color, (x - 40, y-160, 41, 40))
        elif state == 3:
            for i in range(0,3):
                pygame.draw.rect(mainwindow,color, (x-40, y, 41, 40))
                x += 40
            pygame.draw.rect(mainwindow,color, (x-80, y-40, 41, 40))
    def J(x,y,state,color):
        if state == 0:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x+40, y - 40, 41, 40))
                y += 40
            pygame.draw.rect(mainwindow, color, (x, y - 80, 41, 40))
        elif state == 1:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x, y, 41, 40))
                x += 40
            pygame.draw.rect(mainwindow, color, (x - 120, y - 40, 41, 40))
        elif state == 2:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x+40, y-40, 41, 40))
                y += 40
            pygame.draw.rect(mainwindow, color, (x + 80, y - 160, 41, 40))
        elif state == 3:
            for i in range(0,3):
                pygame.draw.rect(mainwindow, color, (x, y, 41, 40))
                x += 40
            pygame.draw.rect(mainwindow, color, (x - 40, y+40, 41, 40))
    def O(x,y,state,color):
        for i in range(0,2):
            for ii in range(0,2):
                pygame.draw.rect(mainwindow,color,(x,y,41,40))
                x += 40
            x -= 80
            y += 40
    def Z(x,y,state,color):
        if state == 0:
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x+40,y,41,40))
                y += 40
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x,y-40,41,40))
                y += 40
        if state == 1:
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x,y+40,41,40))
                x -= 40
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x+80,y+80,41,40))
                x += 40
        if state == 2:
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x,y,41,40))
                y += 40
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x-40,y-40,41,40))
                y += 40
        if state == 3:
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x-40,y,41,40))
                x += 40
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x-80,y+40,41,40))
                x += 40
    def S(x,y,state,color):
        if state == 0:
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x,y,41,40))
                y += 40
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x+40,y-40,41,40))
                y += 40
        if state == 1:
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x+40,y+40,41,40))
                x -= 40
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x+40,y+80,41,40))
                x += 40
        if state == 2:
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x-40,y,41,40))
                y += 40
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x,y-40,41,40))
                y += 40
        if state == 3:
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x,y,41,40))
                x += 40
            for i in range(0,2):
                pygame.draw.rect(mainwindow,color,(x-120,y+40,41,40))
                x += 40
    def T(x,y,state,color):
        if state == 0:
            pygame.draw.rect(mainwindow,color, (x, y, 41, 40))
            for i in range(0,3):
                pygame.draw.rect(mainwindow,color,(x-40,y+40,41,40))
                x += 40
        if state == 1:
            for i in range(0,3):
                pygame.draw.rect(mainwindow,color, (x, y, 41, 40))
                y += 40
            pygame.draw.rect(mainwindow,color, (x+40, y-80, 41, 40))
        if state == 2:
            for i in range(0,3):
                pygame.draw.rect(mainwindow,color, (x-40, y+40, 41, 40))
                x += 40
            pygame.draw.rect(mainwindow,color, (x-120, y+80, 41, 40))
        if state == 3:
            for i in range(0,3):
                pygame.draw.rect(mainwindow,color, (x, y, 41, 40))
                y += 40
            pygame.draw.rect(mainwindow,color, (x-40, y-80, 41, 40))

    QUIT = False
    count = 0
    count2 = 0
    plus = 0
    shapes_xy = [[],[],[],[],[],[],[]]
    shapes = [[],[],[],[],[],[],[]]
    states = [[],[],[],[],[],[],[]]

    zone = [[0,0,0,0,0,0,0,0,0,0],     #  window: 750 x 950
            [0,0,0,0,0,0,0,0,0,0],      #  tetris zone: 400 x 800 
            [0,0,0,0,0,0,0,0,0,0],      #  start_coors: (160,100)
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0]]

    c_zone = [[0,0,0,0,0,0,0,0,0,0],     #  window: 750 x 950
            [0,0,0,0,0,0,0,0,0,0],      #  tetris zone: 400 x 800 
            [0,0,0,0,0,0,0,0,0,0],      #  start_coors: (160,100)
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0],
            [0,0,0,0,0,0,0,0,0,0]]

    TOUCH = [True]

    def updatezone():
        zone.clear()
        for i in range(0,20):
            zone.append(c_zone[i].copy())

    def updatec_zone():
        c_zone.clear()
        for i in range(0,20):
            c_zone.append(zone[i].copy())

    def printc_zone(): #This function is for the testing
        for i in range(0,20):
            print(c_zone[i])
        print('------------------------------')

    def updategrid(window_x,window_y,color,width):
        gw_width = 400
        gw_height = 800
        side = 40
        yy = window_y
        for i in range(0,math.floor(gw_height/side)):
            xx = window_x
            for ii in range(0,math.floor(gw_width/side)):
                pygame.draw.rect(mainwindow,color,(xx,yy,41,41),width)
                xx += 40
            yy += 40

    def updatetetris():
        y = 100
        for i in range(0,20):
            x = 160
            for ii in range(0,10):
                if c_zone[i][ii] == 0:
                    pygame.draw.rect(mainwindow,GREY,(x,y,41,41))
                if c_zone[i][ii] == 1:
                    pygame.draw.rect(mainwindow,LIGHTBLUE,(x,y,41,41))
                x += 40
            y += 40

    def moveASD(ASD):
        if ASD == 'A' and 160 < shapes_xy[shape][len(shapes_xy[shape])-1][0]:
            shapes_xy[shape][len(shapes_xy[shape])-1][0] -= 40
            LRD[0][0] -= 1
        elif ASD == 'D' and shapes_xy[shape][len(shapes_xy[shape])-1][0] < 520:
            shapes_xy[shape][len(shapes_xy[shape])-1][0] += 40  
            LRD[0][0] += 1
        if ASD == 'S':
            LRD[2][0] += 1

    def rotation(shape,count):
        if states[shape][count] < 3:
            states[shape][count] += 1
        else :
            states[shape][count] = 0

    #def testnextmove():
    #    if count % 60 == 0 and shapes_xy[shape][len(shapes_xy[shape])-1][1] < 820:
    #        shapes_xy[shape][len(shapes_xy[shape])-1][1] += 40
    #        LRD[2][0] += 1
#
    #def testcollision():
    #    if shapes_xy[shape][len(shapes_xy[shape])-1][1] >= 820:
    #        if count % 60 == 0:
    #            TOUCH = True
    #            return TOUCH
     #   elif zone.count((shapes_xy[shape][len(shapes_xy[shape])-1][1] + 40)) == 1:
     #       if count % 60 == 0:
     #           TOUCH = True
      #          return TOUCH 
      #  testnextmove()
    
    def touching(x):
        if c_zone[x+LRD[2][0]][LRD[0][0]] != 0 and count % 60 == 0:
            TOUCH.append(True)
            return True

    def grounding(x):
        if x == 3 and x+LRD[2][0] == 19 and count % 60 == 0:
            TOUCH.append(True)
            updatezone()
            return True

    def falling(x):
        if c_zone[x+LRD[2][0]][LRD[0][0]] == 0:
            return False

    def moverow():
        pass

    def g_shapes(shape,shapes_x,shapes_y,states):
        if shape == 0:
            I(shapes_x,shapes_y,states,LIGHTBLUE)
        elif shape == 1:
            L(shapes_x, shapes_y,states,ORANGE)
        elif shape == 2:
            J(shapes_x, shapes_y,states,BLUE)
        elif shape == 3:
            O(shapes_x,shapes_y,states,YELLOW)
        elif shape == 4:
            Z(shapes_x,shapes_y,states,RED)
        elif shape == 5:
            S(shapes_x,shapes_y,states,GREEN)
        elif shape == 6:
            T(shapes_x,shapes_y,states,PURPLE)


    while not QUIT:
        mouse = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()
        mainwindow.blit(background,(0,0))
        count += 1
        count2 += plus
        if TOUCH[-1] == True:
            LRD = [[4],[0],[0]]
            #shape = random.randint(0,6)
            shape = 0
            shapes[shape].append(shape)
            if shape == 0:
                states[0].append(0)
            elif shape == 1:
                states[1].append(0)
            elif shape == 2:
                states[2].append(0)
            elif shape == 3:
                states[3].append(0)
            elif shape == 4:
                states[4].append(0)
            elif shape == 5:
                states[5].append(0)
            elif shape == 6:
                states[6].append(0)
            shapes_xy[shape].append([320,180])
            TOUCH.append(False)


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    shapes_xy[shape][len(shapes_xy[shape])-1][1] = 820
                    TOUCH[-1] = True
                if event.key == pygame.K_w:
                    rotation(shape,len(states[shape])-1)
                if event.key == pygame.K_a:
                    count2 = 0
                    plus = -1
                    moveASD('A')
                if event.key == pygame.K_d:
                    count2 = 0
                    plus = 1
                    moveASD('D')
                if event.key == pygame.K_s:
                    moveASD('S')
            if event.type == pygame.KEYUP:
                plus = 0
        
        if count2 % 8 == 0 and count2 < 0:
            moveASD(True)
        if count2 % 8 == 0 and count2 > 0:
            moveASD(False)

        for i in range(0,7):
            try:
                for ii in range(0,len(shapes[i])):
                    g_shapes(shapes[i][ii],shapes_xy[i][ii][0],shapes_xy[i][ii][1],states[i][ii])
            except:
                i -= 1

        updatetetris()

        if count % 60 == 0:
            printc_zone()
        if count % 60 == 0:
            LRD[2][0] += 1


        text_display(mainwindow,'SCORE',30,(70,40),WHITE)
        text_display(mainwindow,'LEVEL',30,(70,200),WHITE)
        text_display(mainwindow,'HOLD',30,(670,40),WHITE)
        text_display(mainwindow,'NEXT',30,(670,200),WHITE)
        if 20 < mouse[0] < 100 and 880 < mouse[1] < 920:
            buttom(mainwindow,LIGHTGREY,(20,880),(80,40),'BACK',20,WHITE)
            if click[0] == 1:
                return
        else:
            buttom(mainwindow,GREY,(20,880),(80,40),'BACK',20,WHITE)


        updategrid(160,100,WHITE,2)
        pygame.display.update()
        clock.tick(60)


while True:
    LEVEL = startmenu()
    if LEVEL == 'Go':
        mainloop()
    elif LEVEL == 'Stats':
        stats()
    elif LEVEL == 'Exit':
        pygame.quit()
        quit()